from flask import Flask, render_template, make_response
import gspread
import pandas as pd
import folium
from google.oauth2.service_account import Credentials

app = Flask(__name__)

# Google Sheets setup
SHEET_KEY = "1Z00_qe8VCwUXUOmZ4mu_y0ROCcqMaGy67-mhwSclD70"

# Define scope for Google Sheets API
scope = ["https://www.googleapis.com/auth/spreadsheets",
         "https://www.googleapis.com/auth/drive"]

# Authorize with service account
creds = Credentials.from_service_account_file("service_account.json", scopes=scope)
gc = gspread.authorize(creds)


@app.route("/")
def index():
    # Open Google Sheet
    try:
        spreadsheet = gc.open_by_key(SHEET_KEY)
        worksheet1 = spreadsheet.worksheet("Engineer")
        worksheet2 = spreadsheet.worksheet("Customer")
    except gspread.exceptions.APIError as e:
        return f"Error accessing Google Sheet: {e}", 500

    # Convert to DataFrame
    df1 = pd.DataFrame(worksheet1.get_all_values())
    df2 = pd.DataFrame(worksheet2.get_all_values())

    # Set headers
    df1.columns = df1.iloc[0]; df1 = df1.drop(0)
    df2.columns = df2.iloc[0]; df2 = df2.drop(0)

    # Convert lat/long to float
    df1["Latitude"] = pd.to_numeric(df1["Latitude"], errors="coerce")
    df1["Longitude"] = pd.to_numeric(df1["Longitude"], errors="coerce")
    df2["Latitude"] = pd.to_numeric(df2["Latitude"], errors="coerce")
    df2["Longitude"] = pd.to_numeric(df2["Longitude"], errors="coerce")

    # Drop rows with missing coordinates
    df1 = df1.dropna(subset=["Latitude", "Longitude"])
    df2 = df2.dropna(subset=["Latitude", "Longitude"])

    # Create base map centered at average location
    center_lat = pd.concat([df1["Latitude"], df2["Latitude"]]).mean()
    center_lon = pd.concat([df1["Longitude"], df2["Longitude"]]).mean()
    m = folium.Map(location=[center_lat, center_lon], zoom_start=6)

    # Add Engineer markers
    for _, row in df1.iterrows():
        if row["TYPE"] == "PACK":
            icon_color = "blue"
            icon_symbol = "cog"
        else:
            icon_color = "green"
            icon_symbol = "wrench"

        popup_html = folium.Popup(
            f"""
            <b>Engineer</b><br>
            EnqNo: {row['EnqNo']}<br>
            Name: {row['Name']}<br>
            City: {row['City']}<br>
            State: {row['BillState']}<br>
            Type: {row['TYPE']}
            """,
            max_width=300
        )
        folium.Marker(
            location=[row["Latitude"], row["Longitude"]],
            popup=popup_html,
            tooltip=row["Name"],
            icon=folium.Icon(color=icon_color, icon=icon_symbol, prefix="fa")
        ).add_to(m)

    # Add Customer markers
    for _, row in df2.iterrows():
        if row["TYPE"] == "PACK":
            icon_color = "blue"
            icon_symbol = "user"
        else:
            icon_color = "green"
            icon_symbol = "user"

        popup_html = folium.Popup(
            f"""
            <b>Customer</b><br>
            EnqNo: {row['EnqNo']}<br>
            Name: {row['Name']}<br>
            City: {row['City']}<br>
            State: {row['BillState']}<br>
            Type: {row['TYPE']}
            """,
            max_width=300
        )
        folium.Marker(
            location=[row["Latitude"], row["Longitude"]],
            popup=popup_html,
            tooltip=row["Name"],
            icon=folium.Icon(color=icon_color, icon=icon_symbol, prefix="fa")
        ).add_to(m)

    # Convert map to HTML and return it directly
    map_html = m.get_root().render()
    response = make_response(map_html)

    # Add caching headers to prevent browser/proxy caching
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'

    return response


if __name__ == "__main__":
    app.run(debug=True)
